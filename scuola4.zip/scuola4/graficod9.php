<?php
$conn=mysqli_connect("localhost","root","","scuola4") or die("Fallita connessione con il database!!!!");

// This example will display a pie chart. If you need other charts such as a Bar chart, you will need to modify the code a little to make it work with bar chart and other charts

   $QR11=mysqli_query($conn,"Select count(domanda9) from risposte_04 where domanda9=1");
   $QR12=mysqli_query($conn,"Select count(domanda9) from risposte_04 where domanda9=2");
   $QR13=mysqli_query($conn,"Select count(domanda9) from risposte_04 where domanda9=3");
   $QR14=mysqli_query($conn,"Select count(domanda9) from risposte_04 where domanda9=4");
   if (!$QR11) { die("Errore nella query QR9_1: " . mysqli_error($conn)); } 
   if (!$QR12) { die("Errore nella query QR9_2: " . mysqli_error($conn)); } 
   if (!$QR13) { die("Errore nella query QR9_3: " . mysqli_error($conn)); } 
   if (!$QR14) { die("Errore nella query QR9_4: " . mysqli_error($conn)); } 
   

   $R11 = mysqli_fetch_row($QR11); 
   $R12 = mysqli_fetch_row($QR12);
   $R13 = mysqli_fetch_row($QR13); 
   $R14 = mysqli_fetch_row($QR14);
   
$Risposta1="Risposta 01";
$Risposta2="Risposta 02";
$Risposta3="Risposta 03";
$Risposta4="Risposta 04";

$drop="drop table if exists Domanda9";
$Del=mysqli_query($conn,$drop) or die ("Errore cancellazione tabella Domanda 9!!!");
$q1="CREATE TABLE `scuola4`.`Domanda9` (`Risposta` VARCHAR(50) NOT NULL , `Numero` INT NOT NULL) ENGINE = MyISAM";
   $OK1=mysqli_query($conn,$q1) or die ("Errore creazione tabella Risposta1!!!");
if($OK1)
{
 $q2="INSERT into Domanda9 (Risposta, Numero) VALUES ('$Risposta1', '$R11[0]')";
 $in=mysqli_query($conn,$q2);
if(!$in)
 echo "Errore Query registrazione dati Risposta 1</BR> ";
$q2="INSERT into Domanda9 (Risposta, Numero) VALUES ('$Risposta2', '$R12[0]')";
 $in=mysqli_query($conn,$q2);
if(!$in)
 echo "Errore Query registrazione dati Risposta 2 </BR>";
$q2="INSERT into Domanda9 (Risposta, Numero) VALUES ('$Risposta3', '$R13[0]')";
 $in=mysqli_query($conn,$q2);
if(!$in)
 echo "Errore Query registrazione dati Risposta 3 </BR>";
$q2="INSERT into Domanda9 (Risposta, Numero) VALUES ('$Risposta4', '$R14[0]')";
 $in=mysqli_query($conn,$q2);
if(!$in)
 echo "Errore Query registrazione dati Risposta 4 </BR>";

//Grafico degli esiti della Domanda9
$sth = mysqli_query($conn,"SELECT * FROM Domanda9");

}

//flag is not needed
$flag = true;
$table = array();
$table['cols'] = array(

    // Labels for your chart, these represent the column titles
    // Note that one column is in "string" format and another one is in "number" format as pie chart only required "numbers" for calculating percentage and string will be used for column title
    array('label' => 'Risposta', 'type' => 'string'),
    array('label' => 'Numero', 'type' => 'number')

);

$rows = array();
while($r = mysqli_fetch_assoc($sth)) {
    $temp = array();
    // the following line will be used to slice the Pie chart
    $temp[] = array('v' => (string) $r['Risposta']); 

    // Values of each slice
    $temp[] = array('v' => (int) $r['Numero']); 
    $rows[] = array('c' => $temp);
}

$table['rows'] = $rows;
$jsonTable = json_encode($table);
//echo $jsonTable;
?>

<html>
  <head>
    <!--Load the Ajax API-->
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script type="text/javascript">

    // Load the Visualization API and the piechart package.
    google.load('visualization', '1', {'packages':['corechart']});

    // Set a callback to run when the Google Visualization API is loaded.
    google.setOnLoadCallback(drawChart);

    function drawChart() {

      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.DataTable(<?=$jsonTable?>);
      var options = {
           title: 'Esiti Domanda N.9',
          is3D: 'true',
          width: 800,
          height: 600
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
      var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
      chart.draw(data, options);
    }
    </script>
  </head>

  <body>
    <!--this is the div that will hold the pie chart-->
    <div id="chart_div"></div>
  </body>
</html>
