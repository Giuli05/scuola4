<?php

$conn = MySqli_connect ("localhost", "root", "", "scuola4");
if (!$conn)  {
    echo("Errore di connessione". mysqli_connect_error ) ;}
    $eta = $_POST [ "eta" ];
    $impiego = $_POST [ "impiego" ];
    $sesso = $_POST [ "sesso" ];

    $domanda1 = $_POST [ "domanda1" ];
    $domanda2 = $_POST [ "domanda2" ];
    $domanda3 = $_POST [ "domanda3" ];
    $domanda4 = $_POST [ "domanda4" ];
    $domanda5 = $_POST [ "domanda5" ];

    $domanda6_1 = $_POST [ "domanda6_1" ];
    $domanda6_2 = $_POST [ "domanda6_2" ];
    $domanda6_3 = $_POST [ "domanda6_3" ];
    $domanda6_4 = $_POST [ "domanda6_4" ];

    $domanda7 = $_POST [ "domanda7" ];

    $domanda8_1 = $_POST [ "domanda8_1" ];
    $domanda8_2 = $_POST [ "domanda8_2" ];
    $domanda8_3 = $_POST [ "domanda8_3" ];
    $domanda8_4 = $_POST [ "domanda8_4" ];

    $domanda9 = $_POST [ "domanda9" ];

    $domanda10_1 = $_POST [ "domanda10_1" ];
    $domanda10_2 = $_POST [ "domanda10_2" ];
    $domanda10_3= $_POST  [ "domanda10_3" ];
    $domanda10_4 = $_POST [ "domanda10_4" ];

    $link="http://127.0.0.1/scuola4/Generale%20grafici.html";


    $sql = "INSERT INTO risposte_04 (eta, impiego, sesso, domanda1, domanda2, domanda3, domanda4, domanda5, domanda6_1, domanda6_2, domanda6_3, domanda6_4 ,domanda7, domanda8_1,domanda8_2, domanda8_3, domanda8_4, domanda9, domanda10_1, domanda10_2, domanda10_3, domanda10_4 ) 
    VALUES ('$eta','$impiego','$sesso','$domanda1', '$domanda2', '$domanda3', '$domanda4', '$domanda5', '$domanda6_1', '$domanda6_2', '$domanda6_3', '$domanda6_4', '$domanda7', '$domanda8_1', '$domanda8_2',
     '$domanda8_3', '$domanda8_4', '$domanda9', '$domanda10_1', '$domanda10_2', '$domanda10_3', '$domanda10_4') ";

if (mysqli_query($conn, $sql) ){
    echo "Valore aggiunto con successo"; 

     
   echo  "<a href=".$link."> Clicca qui per accedere alla pagina con i grafici </a>";

    } else {
    echo "Errore nell'aggiunta del valore: "
    . mysqli_error ($conn);
    } 

    mysqli_close($conn);

?>